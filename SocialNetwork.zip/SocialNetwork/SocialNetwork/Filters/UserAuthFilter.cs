﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Server.HttpSys;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace SocialNetwork.Filters
{
    public class UserAuthFilter:ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            string value = filterContext.HttpContext.Request.Query["token"];
            var handler = new JwtSecurityTokenHandler();
            try
            {
                var token = handler.ReadJwtToken(value);
                var user = token.Claims.First(claim => claim.Type == ClaimTypes.Role);
                if (user == null || user.Value != "User")
                {
                    filterContext.Result = new UnauthorizedObjectResult("Invalid authorization token");
                }
                else
                {
                    string email = filterContext.HttpContext.Request.Query["Email"];
                    var claimEmail = token.Claims.First(claim => claim.Type == ClaimTypes.Email);
                    if (email != claimEmail.Value)
                    {
                        filterContext.HttpContext.Request.Headers.Add("Viewer", "true");
                    }
                    else
                    {
                        filterContext.HttpContext.Request.Headers.Add("Viewer", "false");
                    }
                }
            }
            catch(Exception e)
            {
                filterContext.Result = new UnauthorizedObjectResult("Invalid authorization token"+e);
            }
                
        }
    }
}
