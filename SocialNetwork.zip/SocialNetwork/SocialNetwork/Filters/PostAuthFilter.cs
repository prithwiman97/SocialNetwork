﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using SocialNetwork.Models;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading.Tasks;

namespace SocialNetwork.Filters
{
    public class PostAuthFilter:ActionFilterAttribute
    {
        private readonly SocialContext _context;
        public PostAuthFilter(SocialContext context)
        {
            _context = context;
        }
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            string value = context.HttpContext.Request.Query["token"];
            if (value != null)
            {
                int id = int.Parse(context.HttpContext.Request.Query["Id"]);
                var token = new JwtSecurityTokenHandler().ReadJwtToken(value);
                Post p = _context.Posts.Find(id);
                int userId = int.Parse(token.Claims.First(claim => claim.Type == "UserId").Value);
                if (p.UserId != userId)
                    context.Result = new UnauthorizedObjectResult("Unauthorized User");
            }
            else
                context.Result = new UnauthorizedObjectResult("You do not have a token");
        }
    }
}
