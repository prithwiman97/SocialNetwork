﻿using SocialNetwork.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SocialNetwork.ViewModels
{
    public class PostInfo
    {
        public Post Post { get; set; }
        public Users User { get; set; }
    }
}
