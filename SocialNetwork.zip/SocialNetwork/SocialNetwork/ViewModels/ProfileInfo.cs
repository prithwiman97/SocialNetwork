﻿using SocialNetwork.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocialNetwork.ViewModels
{
    public class ProfileInfo
    {
        public int OwnerId { get; set; }
        public Users User { get; set; }
        public IEnumerable<Post> Posts { get; set; }
        public IEnumerable<Users> OwnerFriends { get; set; }
        public IEnumerable<Users> UserFriends { get; set; }
        public IEnumerable<Users> RequestsReceived { get; set; }
        public IEnumerable<Users> RequestsSent { get; set; }
    }
}