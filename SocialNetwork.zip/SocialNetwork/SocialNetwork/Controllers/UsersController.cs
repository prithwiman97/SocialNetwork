﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Configuration;
using SocialNetwork.Filters;
using SocialNetwork.Models;
using SocialNetwork.ViewModels;

namespace SocialNetwork.Controllers
{
    public class UsersController : Controller
    {
        private readonly SocialContext _context;
        private IConfiguration Configuration { get; }
        public UsersController(SocialContext context, IConfiguration configuration)
        {
            _context = context;
            Configuration = configuration;
        }

        public IEnumerable<Users> Search(string name)
        {
            name = name.ToLower();
            string[] keywords = name.Split(" ");
            IEnumerable<Users> users = _context.Users.ToList();
            List < Users > found = new List<Users>();
            foreach(Users u in users)
            {
                int flag = 0;
                foreach(string k in keywords)
                {
                    if(u.Firstname.ToLower().Contains(k) || u.Lastname.ToLower().Contains(k))
                    {
                        flag = 1;
                        break;
                    }
                }
                if (flag == 1)
                    found.Add(u);
            }
            return found;
        }
        public IActionResult Index()
        {
            return View();
        }
        public ActionResult New()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Create(Users user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
            string token = new AuthController(_context, Configuration).Post(user).ToString();
            return RedirectToAction("Profile", new { Email = user.Email, token = token });
        }

        //[UserAuthFilter]
        public ActionResult Profile(string Email,string token)
        {
            Users user = _context.Users.SingleOrDefault(u => u.Email==Email);
            //Retrieiving posts made by user
            IEnumerable<Post> posts = _context.Posts.ToList();
            posts = from p in posts where p.UserId == user.Id orderby p.DateOfPublish descending select p;
            //Use token to retrieve friend requests and options for navbar
            var t = new JwtSecurityTokenHandler().ReadJwtToken(token);
            int ownerId = int.Parse(t.Claims.First(c => c.Type == "UserId").Value);
            //Retrieving friendlist
            IEnumerable<Users> users = _context.Users.ToList();
            IEnumerable<Friends> friends = _context.Friends.ToList();
            friends = from f in friends where f.UserId == user.Id select f;
            IEnumerable<Users> userfriendList = from f in friends join u in users on f.FriendId equals u.Id select u;
            friends = from f in friends where f.UserId == ownerId select f;
            IEnumerable<Users> ownerfriendList = from f in friends join u in users on f.FriendId equals u.Id select u;
            //Retrieving Friend requests received
            IEnumerable<FriendRequest> friendRequests = _context.FriendRequests.ToList();
            friendRequests = from fr in friendRequests where fr.ReceiverId == ownerId select fr;
            IEnumerable<Users> requestsReceived = from fr in friendRequests join u in users on fr.SenderId equals u.Id select u;
            //Retrieving Freind requests sent
            friendRequests = _context.FriendRequests.ToList();
            friendRequests = from fr in friendRequests where fr.SenderId == ownerId select fr;
            IEnumerable<Users> requestsSent = from fr in friendRequests join u in users on fr.ReceiverId equals u.Id select u;
            //Building profile info from above data
            ProfileInfo profile = new ProfileInfo
            {
                OwnerId = ownerId,
                User = user,
                UserFriends = userfriendList,
                OwnerFriends = ownerfriendList,
                RequestsReceived = requestsReceived,
                RequestsSent = requestsSent,
                Posts = posts
            };
            return View(profile);
        }
        
    }
}