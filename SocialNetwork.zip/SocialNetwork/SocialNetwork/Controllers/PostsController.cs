﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using SocialNetwork.Filters;
using SocialNetwork.Models;
using SocialNetwork.ViewModels;

namespace SocialNetwork.Controllers
{
    public class PostsController : Controller
    {
        private readonly SocialContext _context;
        public PostsController(SocialContext context)
        {
            _context = context;
        }

        [Route("/Posts/{UserId}")]
        [HttpGet("{UserId}")]
        public IEnumerable<PostInfo> Get(int UserId)
        {
            IEnumerable<Post> posts = _context.Posts.ToList();
            IEnumerable<Friends> friends = _context.Friends.ToList();
            IEnumerable<Users> users = _context.Users.ToList();
            friends = from f in friends where f.UserId == UserId select f;
            posts = from p in posts join f in friends on p.UserId equals f.FriendId orderby p.DateOfPublish descending select p;
            IEnumerable<PostInfo> postInfos = from p in posts join u in users on p.UserId equals u.Id select new PostInfo { Post=p,User=u};
            return postInfos;
        }

        [HttpPost]
        public ActionResult Create(Post post, string token)
        {
            _context.Posts.Add(post);
            _context.SaveChanges();
            Users user = _context.Users.Find(post.UserId);
            return RedirectToAction("Profile", "Users", new { Email = user.Email, token = token });
        }


        [TypeFilter(typeof(PostAuthFilter))]
        public ActionResult Delete(int Id,string token)
        {
            Post post = _context.Posts.Find(Id);
            _context.Posts.Remove(_context.Posts.Single(p => p.Id == Id));
            _context.SaveChanges();
            Users user = _context.Users.Find(post.UserId);
            return RedirectToAction("Profile", "Users", new { Email = user.Email, token=token });
        }


        [TypeFilter(typeof(PostAuthFilter))]
        public ActionResult Edit(int Id,string token)
        {
            Post post = _context.Posts.Find(Id);
            Users user = _context.Users.Find(post.UserId);
            PostInfo postInfo = new PostInfo
            {
                Post = post,
                User = user
            };
            return View(postInfo);
        }


        
        public ActionResult Save(Post post, string token)
        {
            _context.Posts.Update(post);
            _context.SaveChanges();
            Users user = _context.Users.Find(post.UserId);
            return RedirectToAction("Profile", "Users", new { Email = user.Email, token=token });
        }
    }
}