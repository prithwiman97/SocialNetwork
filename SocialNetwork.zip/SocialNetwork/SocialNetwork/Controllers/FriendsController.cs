﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SocialNetwork.Models;

namespace SocialNetwork.Controllers
{
    public class FriendsController : Controller
    {
        private readonly SocialContext _context;
        public FriendsController(SocialContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Accept(int uid,int fid)
        {
            Friends f1 = new Friends
            {
                UserId = uid,
                FriendId = fid
            };
            Friends f2 = new Friends
            {
                UserId = fid,
                FriendId = uid
            };
            _context.Friends.Add(f1);
            _context.Friends.Add(f2);
            _context.SaveChanges();
            return Ok();
        }
        public IActionResult Unfriend(int uid,int fid)
        {
            _context.Friends.Remove(_context.Friends.Single(f => f.UserId == uid && f.FriendId == fid));
            _context.Friends.Remove(_context.Friends.Single(f => f.UserId == fid && f.FriendId == uid));
            _context.SaveChanges();
            return Ok();
        }
    }
}