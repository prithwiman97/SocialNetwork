﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SocialNetwork.Models;

namespace SocialNetwork.Controllers
{
    public class FriendRequestsController : Controller
    {
        private readonly SocialContext _context;
        public FriendRequestsController(SocialContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Accept(int sid,int rid)
        {
            _context.FriendRequests.Remove(_context.FriendRequests.Single(r => r.SenderId == sid && r.ReceiverId == rid));
            if (_context.SaveChanges() == 1)
                return RedirectToAction("Accept","Friends",new { uid=sid,fid=rid });
            return BadRequest();
        }
        public IActionResult Send(int sid,int rid,string token)
        {
            FriendRequest friendRequest = new FriendRequest
            {
                SenderId = sid,
                ReceiverId = rid
            };
            _context.FriendRequests.Add(friendRequest);
            if (_context.SaveChanges() == 1)
                return Ok();
            return BadRequest();
        }
        public IActionResult Delete(int sid,int rid,string token)
        {
            _context.FriendRequests.Remove(_context.FriendRequests.Single(r => r.SenderId == sid && r.ReceiverId == rid));
            if(_context.SaveChanges() == 1)
                return Ok();
            return BadRequest();
        }
    }
}