﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using SocialNetwork.Models;

namespace SocialNetwork.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly SocialContext _context;
        private IConfiguration Configuration { get; }
        public AuthController(SocialContext context,IConfiguration configuration)
        {
            _context = context;
            Configuration = configuration;
        }
        [HttpPost]
        public string Post([FromBody] Users u)
        {
            Users user = _context.Users.SingleOrDefault(c => c.Email == u.Email);
            if (user!=null)
            {
                if(user.Password == u.Password)
                {
                    string token = GenerateToken(user);
                    return token;
                }
                HttpContext.Response.StatusCode = 400;
                return "Password Mismatch";
            }
            HttpContext.Response.StatusCode = 400;
            return "Email does not exist";
        }
        private string GenerateToken(Users user)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["TokenInfo:SecurityKey"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var claims = new List<Claim>
            {
                new Claim("UserId",user.Id.ToString()),
                new Claim(ClaimTypes.Role,"User"),
                new Claim(ClaimTypes.Email,user.Email),
                new Claim(ClaimTypes.Name,user.Firstname),
                new Claim(ClaimTypes.Surname,user.Lastname),
                new Claim(ClaimTypes.DateOfBirth,user.DOB.ToString()),
                new Claim(ClaimTypes.Gender,user.Gender)
            };
            var token = new JwtSecurityToken(
                issuer:Configuration["TokenInfo:Issuer"],
                audience:Configuration["TokenInfo:Audience"],
                claims:claims,
                expires:DateTime.Now.AddMinutes(2),
                signingCredentials:credentials
            );
            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}