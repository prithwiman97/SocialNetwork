﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SocialNetwork.Models
{
    public class Users
    {
        public int Id { get; set; }
        
        public string Firstname { get; set; }
        
        public string Lastname { get; set; }

        
        [Display(Name = "Email Id")]
        public string Email { get; set; }
        
        public string Password { get; set; }


        [Display(Name = "Date Of Birth")]
        public DateTime DOB { get; set; }

        public string Gender { get; set; }
    }
}