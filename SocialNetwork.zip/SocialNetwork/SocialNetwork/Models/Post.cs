﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocialNetwork.Models
{
    public class Post
    {
        public int Id { get; set; }
        public string Caption { get; set; }
        public DateTime DateOfPublish { get; set; }
        public int UserId { get; set; }
    }
}