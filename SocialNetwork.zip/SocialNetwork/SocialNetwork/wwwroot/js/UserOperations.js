﻿function searchUsers(name, token) {
    let results = document.getElementById('results');
    results.innerHTML = '';
    results.classList.remove('border');
    if (name != '') {
        let xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                results.classList.add('border');
                let users = JSON.parse(this.responseText);
                for (let u of users)
                    results.innerHTML = results.innerHTML + `
                    <a href="/Users/Profile?Email=${u.email}&token=${token}" class="dropdown-item">${u.firstname + ' ' + u.lastname}</a>
                `;
            }
        };
        xhr.open('GET', '/Users/Search?name=' + name, true);
        xhr.send();
    }
}