﻿function retrievePosts(ownerId,token) {
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            let postInfos = JSON.parse(this.responseText);
            let postsContainer = document.getElementById('postsFromFriends');
            postsContainer.innerHTML = '';
            for (let pI of postInfos) {
                console.log(pI);
                let post = document.createElement('div');
                post.className = 'container border rounded shadow mt-4 mb-5';
                post.innerHTML = `
                    <div class="row border-bottom pt-2">
                        <div class="col-sm-12">
                            <h5>
                                Posted by
                                <a href="/Users/Profile?Email=${pI.user.email}&token=${token}">
                                    ${pI.user.firstname}
                                </a>
                                on ${pI.post.dateOfPublish.split('T')[0]}
                            </h5>
                        </div>
                    </div>
                    <div class="row border-bottom p-3">
                        <div class="col">${pI.post.caption}</div>
                    </div>
                    <div class="row border-bottom">
                        <div class="col border-right p-2" align="center">
                            <a href="#">Like <i class="far fa-thumbs-up"></i></a>
                        </div>
                        <div class="col border-right p-2" align="center">
                            <a href="#" class="love">Love <i class="fas fa-heart"></i></a>
                        </div>
                        <div class="col border-right p-2" align="center">
                            <a href="#" class="angry">Angry <i class="far fa-angry"></i></a>
                        </div>
                        <div class="col p-2" align="center">
                            <a href="#">Share <i class="far fa-share-square"></i></a>
                        </div>
                    </div>
                    <form class="row p-2">
                        <div class="col-sm-9">
                            <textarea placeholder="Comment..." class="form-control" required></textarea>
                        </div>
                        <div class="col-sm-3">
                            <input type="submit" class="btn btn-primary" value="Comment" />
                        </div>
                    </form>
                `;
                postsContainer.appendChild(post);
            }
        }
    };
    xhr.open('GET', '/Posts/' + ownerId, true);
    xhr.send();
}