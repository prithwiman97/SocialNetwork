﻿function cancelRequest(sid,rid) {
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            let fr_btn = document.getElementById('fr_btn');
            fr_btn.innerHTML = 'Add Friend <i class="fas fa-user-plus"></i>';
            fr_btn.className = 'btn btn-primary';
            fr_btn.onclick = () => { addFriend(sid, rid); };
        }
    };
    xhr.open('GET', '/FriendRequests/Delete?sid=' + sid + '&rid=' + rid, true);
    xhr.send();
}
function addFriend(sid,rid) {
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            let fr_btn = document.getElementById('fr_btn');
            fr_btn.innerHTML = 'Cancel Request';
            fr_btn.className = 'btn btn-warning';
            fr_btn.onclick = () => { cancelRequest(sid,rid); };
        }
    };
    xhr.open('GET', '/FriendRequests/Send?sid=' + sid + '&rid=' + rid, true);
    xhr.send();
}
function unfriend(uid,fid) {
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            let fr_btn = document.getElementById('fr_btn');
            fr_btn.innerHTML = 'Add Friend <i class="fas fa-user-plus"></i>';
            fr_btn.className = 'btn btn-primary';
            fr_btn.onclick = () => { addFriend(uid, fid); };
        }
    };
    xhr.open('GET', '/Friends/Unfriend?uid=' + uid+'&fid='+fid, true);
    xhr.send();
}
function accept(sid,rid) {
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            let req_count = document.getElementById('req_count');
            let count = parseInt(req_count.innerHTML);
            if (--count == 0)
                req_count.innerHTML = '';
            else
                req_count.innerHTML = count;
            let request = document.getElementById('req_' + sid);
            request.remove();
            let profile_req = document.getElementById('profile_req');
            if (profile_req != null) {
                let fr_btn = document.createElement('button');
                fr_btn.id = 'fr_btn';
                fr_btn.innerHTML = 'Unfriend <i class="fas fa-user-minus"></i>';
                fr_btn.className = 'btn btn-warning';
                fr_btn.onclick = () => { unfriend(sid, rid); };
                profile_req.replaceWith(fr_btn);
            }
        }
    };
    xhr.open('GET', '/FriendRequests/Accept?sid=' + sid + '&rid=' + rid, true);
    xhr.send();
}
function reject(sid,rid) {
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            let req_count = document.getElementById('req_count');
            let count = parseInt(req_count.innerHTML);
            if(--count == 0)
                req_count.innerHTML = '';
            else
                req_count.innerHTML = count;
            let request = document.getElementById('req_' + sid);
            request.remove();
            let profile_req = document.getElementById('profile_req');
            if (profile_req != null) {
                let fr_btn = document.createElement('button');
                fr_btn.id = 'fr_btn';
                fr_btn.innerHTML = 'Add Friend <i class="fas fa-user-plus"></i>';
                fr_btn.className = 'btn btn-primary';
                fr_btn.onclick = () => { addFriend(sid, rid); };
                profile_req.replaceWith(fr_btn);
            }
        }
    };
    xhr.open('GET', '/FriendRequests/Delete?sid=' + sid + '&rid=' + rid, true);
    xhr.send();
}